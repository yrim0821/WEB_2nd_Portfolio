<template>
  <v-app>
    <div style="margin-top:45px"></div>
    <Header/>
    <v-content>
      <router-view/>
    </v-content>

    <Footer/>

    <transition name="fade">
      <v-btn class="button" v-if="offsetTop>500" fab small @click="$vuetify.goTo(0, 'easeOutQuad')"><v-icon>keyboard_arrow_up</v-icon></v-btn>
    </transition>
    <transition name="fade">
      <v-btn class="button" v-if="offsetTop<=500" fab small v-on:click="bookmarksite('타이틀', 'http://www.jynote.net')"><v-icon>star</v-icon></v-btn>
    </transition>
  </v-app>
</template>


<script>
import store from './store'
import Header from './components/Header'
import Footer from './components/Footer'

export default {
	name: 'App',
	store,
	data: () => ({
    offsetTop: 0
  }),
  components: {
    'Header': Header,
    'Footer': Footer
  },
  methods: {
    handleScroll(){
      this.offsetTop = window.scrollY;
    },
    bookmarksite(title,url) {
       // Internet Explorer
       if(document.all)
       {
           window.external.AddFavorite(url, title);
       }
       // Google Chrome
       else if(window.chrome){
          alert("Ctrl+D키를 누르시면 즐겨찾기에 추가하실 수 있습니다.");
       }
       // Firefox
       else if (window.sidebar) // firefox
       {
           window.sidebar.addPanel(title, url, "");
       }
       // Opera
       else if(window.opera && window.print)
       { // opera
          var elem = document.createElement('a');
          elem.setAttribute('href',url);
          elem.setAttribute('title',title);
          elem.setAttribute('rel','sidebar');
          elem.click();
       }
    }
  },
  created () {
    window.addEventListener('scroll', this.handleScroll);
  },
  destroyed () {
    window.removeEventListener('scroll', this.handleScroll);
  }
}


var agent = navigator.userAgent.toLowerCase();
var name = navigator.appName;

// MS 계열 브라우저를 구분  IE 11+, IE 11,Edge
if(name === 'Microsoft Internet Explorer' || agent.indexOf('trident') > -1 || agent.indexOf('edge/') > -1) {
  alert("해당 브라우저는 크롬에 최적화 되어 있습니다.");
} else if(agent.indexOf('safari') > -1) { // Chrome or Safari
  if(agent.indexOf('chrome') > -1) { // Chrome
  }else{
    alert("해당 브라우저는 크롬에 최적화 되어 있습니다.");
  }
} else if(agent.indexOf('firefox') > -1) { // Firefox
  alert("해당 브라우저는 크롬에 최적화 되어 있습니다.");
}
</script>


<style>
.fade-enter-active, .fade-leave-active {
  transition: opacity .5s;
}
.fade-enter, .fade-leave-to /* .fade-leave-active below version 2.1.8 */ {
  opacity: 0;
}
.button{
  position:fixed;
  bottom:10px;
  right:10px;
  z-index:3
}
</style>
