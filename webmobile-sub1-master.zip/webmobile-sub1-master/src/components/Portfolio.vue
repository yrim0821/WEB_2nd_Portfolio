<template>
  <v-card>
    <v-img :src="imgSrc">
    </v-img>
    <v-card-title primary-title>
      <div style="width:100%">
        <div class="headline portTitle">{{title}}</div>
        <span class="grey--text portBody">{{body}}</span>
      </div>
    </v-card-title>
  </v-card>
</template>

<script>
export default {
	name: 'Portfolio',
	props: {
		date: {type: String},
		title: {type: String},
		body: {type: String},
		imgSrc: {type: String},
	},
	data() {
		return {
			//
		}
	}
}
</script>
<style>
.portTitle{
  width:100%;
  display:block;
  overflow:hidden;
  text-overflow:ellipsis;
  white-space:nowrap;
}

.portBody{
  height: 80px;
  display:block;
  overflow:hidden;
  text-overflow:ellipsis;
}

</style>
