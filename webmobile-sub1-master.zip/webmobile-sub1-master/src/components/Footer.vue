<template>
  <div class="Footer">
    Footer
  </div>
</template>
<script>
  export default{
    name: 'Footer'
  }
</script>

<style>
  .Footer{
    height: 50px;
    background-color: black;
    color: white;
    text-align: center;
  }
</style>
