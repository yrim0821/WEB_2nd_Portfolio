<template>
  <v-app style="position:absolute">

  <div class="toolbar">
    <v-toolbar>
      <v-toolbar-side-icon
        @click.stop="sideNav = !sideNav"
        class="hidden-sm-and-up"><v-icon>menu</v-icon></v-toolbar-side-icon>
      <v-toolbar-title>
        <router-link to="/" tag="span" style="cursor: pointer">SSAFY</router-link>
      </v-toolbar-title>
      <v-spacer></v-spacer>
      <v-toolbar-items class="hidden-xs-only">
        <v-btn
          flat
          v-for="item in menuItems"
          :key="item.title"
          :to="item.link">
          <v-icon left dark>{{ item.icon }}</v-icon>
          {{ item.title }}
        </v-btn>
      </v-toolbar-items>
    </v-toolbar>
  </div>


    <v-navigation-drawer temporary style="position:fixed" v-model="sideNav">
      <v-list>
        <v-list-tile
          v-for="item in menuItems"
          :key="item.title"
          :to="item.link">
          <v-list-tile-action>
            <v-icon>{{ item.icon }}</v-icon>
          </v-list-tile-action>
          <v-list-tile-content>{{ item.title }}</v-list-tile-content>
        </v-list-tile>
      </v-list>
    </v-navigation-drawer>



  </v-app>
</template>

<script>
  export default{
    data () {
        return{
          sideNav: false,
          menuItems: [
            { icon: 'portrait', title: 'Portfolio', link: '/portfolio' },
            { icon: 'photo_filter', title: 'Post', link: '/post' },
            { icon: 'exit_to_app', title: 'Login', link: '/login' },
          ]
        }
     }
  }
</script>


<style>
.toolbar{
  position: fixed;
  width: 100%;
  z-index: 2;
}
</style>
