<template>
  <div>
    <ImgBanner imgSrc="https://source.unsplash.com/random">
      <div style="line-height:1.2em;" slot="text">Inspire the World,<br>Create the Future</div>
    </ImgBanner>

    <v-container>
      <!-- About Me -->
      <v-layout my-5>
        <v-flex class="aboutMe" :class="$mq" xs8>
          <h2 class="headline mb-3">About Me</h2>
          <p class="mr-4">지경민
            <br/>
            Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
          </p>
        </v-flex>
        <v-flex class="profileImg" :class="$mq" xs4>
          <v-img :src="getImgUrl('profile.jpg')" aspect-ratio="1.5"/>
        </v-flex>
      </v-layout>

      <!-- Portfolio -->
      <v-layout my-5>
        <v-flex xs12>
          <router-link to="/portfolio"><h2 class="headline my-5 text-xs-center">Portfolio</h2></router-link>
          <PortfolioList></PortfolioList>
        </v-flex>
      </v-layout>

      <!-- Post -->
      <v-layout my-5>
        <v-flex xs12>
          <router-link to="/post"><h2 class="headline my-5 text-xs-center">Post</h2></router-link>
          <PostList :column="$mq==='mobile' ? 1 : 2"></PostList>
        </v-flex>
      </v-layout>


      <!-- Github -->
      <v-layout my-5>
        <v-flex xs12>
          <h2 class="headline my-5 text-xs-center">Project</h2>
          <RepositoryList></RepositoryList>
        </v-flex>
      </v-layout>
    </v-container>
  </div>
</template>

<script>
import ImgBanner from '../components/ImgBanner'
import PortfolioList from '../components/PortfolioList'
import PostList from '../components/PostList'
import RepositoryList from '../components/RepositoryList'

export default {
	name: 'HomePage',
  data() {
    return{

    }
  },

	components: {
		ImgBanner,
		PortfolioList,
		PostList,
		RepositoryList
	},
	methods: {
		getImgUrl(img) {
			return require('../assets/' + img)
		}
	},
}
</script>




<style>

.profileImg.mobile{
  display: none;
}

.aboutMe.mobile{
  text-align: center;
  margin: 0 auto;
  font-size: 2vw;
}

</style>
